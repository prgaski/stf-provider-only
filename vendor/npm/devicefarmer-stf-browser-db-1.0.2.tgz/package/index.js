module.exports = require('./inventory')
