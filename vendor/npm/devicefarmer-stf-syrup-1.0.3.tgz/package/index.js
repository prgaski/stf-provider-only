(function() {
  var Path;

  Path = require('path');

  module.exports = (function() {
    switch (Path.extname(__filename)) {
      case '.coffee':
        return require('./src/syrup');
      default:
        return require('./lib/syrup');
    }
  })();

}).call(this);
